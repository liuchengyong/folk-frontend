module.exports = function(parameter) {
  return { type: 'OPEN_DIALOG', parameter };
};
