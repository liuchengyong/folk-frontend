module.exports = function(parameter) {
  return { type: 'CLOSE_DIALOG', parameter };
};
