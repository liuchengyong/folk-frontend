/**
 * 登录数据发送中
 * @author HuangGuorui
 * @date   3/25 2016
 */
module.exports = function(parameter) {
	return { type: 'REQUEST_LOGIN_DATA', parameter};
}