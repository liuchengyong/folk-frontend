module.exports = function(parameter) {
  return { type: 'RECEIVE_TOPIC_DATA', parameter };
};
