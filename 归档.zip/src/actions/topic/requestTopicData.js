module.exports = function(parameter) {
  return { type: 'REQUEST_TOPIC_DATA', parameter };
};
