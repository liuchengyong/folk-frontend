module.exports = function(parameter) {
  return { type: 'RECEIVE_KEY_WORD_DATA', parameter };
};
