module.exports = function(parameter) {
  return {type: 'REQUEST_EXPERT_DATA', parameter};
};