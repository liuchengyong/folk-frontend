module.exports = function(parameter) {
	return {type: 'RECEIVE_EXPERT_DATA', parameter};
};