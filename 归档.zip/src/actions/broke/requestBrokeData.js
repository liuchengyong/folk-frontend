module.exports = function(parameter) {
	return { type: 'REQUEST_BROKE_DATA', parameter};
}