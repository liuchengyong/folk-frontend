module.exports = function(parameter) {
	return {type: 'RECEIVE_BROKE_DATA', parameter};
};