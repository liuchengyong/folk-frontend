/**
 * Created by luowei on 3/12/16.
 */
module.exports = function(parameter) {
  return {type: 'RECEIVE_CONSULTATION', parameter};
};