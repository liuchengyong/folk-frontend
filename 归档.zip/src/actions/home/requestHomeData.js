module.exports = function(parameter) {
  return { type: 'REQUEST_HOME_DATA', parameter };
};