/**
 * 注册数据发送中
 * @author HuangGuorui
 * @date   3/24 2016
 */
module.exports = function(parameter) {
	return { type: 'REQUEST_REGISTER_DATA', parameter};
}