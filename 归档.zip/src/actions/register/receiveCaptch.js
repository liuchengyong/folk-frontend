module.exports = function(parameter) {
	return {type: 'RECEIVE_CAPTCH', parameter};
};