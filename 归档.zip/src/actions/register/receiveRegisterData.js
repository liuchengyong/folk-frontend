module.exports = function(parameter) {
	return {type: 'RECEIVE_REGISTER_DATA', parameter};
};