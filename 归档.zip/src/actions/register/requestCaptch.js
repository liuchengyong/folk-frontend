/**
 * 请求验证码
 */
module.exports = function(parameter) {
	return {type: 'REQUEST_CAPTCH', parameter};
};